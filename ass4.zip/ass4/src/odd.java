
public class odd {
	public static void main(String[] args) {
		System.out.println("odd numbers from 1 to 10 are as follows:");
		for(int i=1;i<=10;i++) {
			if(i%2!=0) {
				System.out.println(i);
			}
		}
	}

}
